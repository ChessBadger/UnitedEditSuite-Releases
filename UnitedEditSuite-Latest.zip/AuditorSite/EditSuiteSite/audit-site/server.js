﻿// server.js
const express = require("express");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = process.env.PORT || 3001;
const JSON_DIR = path.resolve(__dirname, "..");

// NEW: report export directory (one level up from audit-site)
const REPORT_DIR = path.resolve(__dirname, "..", "Report-Site");

// Existing audit cache (keep name if you want; this is your current "reportCache")
const reportCache = new Map();
const auditReportFileVersions = new Map();
let lastAuditReportSyncMs = 0;
const AUDIT_REPORT_SYNC_COOLDOWN_MS = 700;

// NEW: report-export cache (area json files)
const reportExportCache = new Map();
const reportExportFileVersions = new Map();
let lastReportExportSyncMs = 0;
const REPORT_EXPORT_SYNC_COOLDOWN_MS = 700;

let enabledDataIndex = {
  enabledReports: [],
  employeeNames: [],
  locationGroups: [],
  recordsByEmployee: new Map(),
  recordsByLocation: new Map(),
  recordsBySku: new Map(),
};

let enabledIndexRebuildTimer = null;

function pushMapArray(map, key, value) {
  if (!key) return;
  if (!map.has(key)) map.set(key, []);
  map.get(key).push(value);
}

function rebuildEnabledDataIndex() {
  const enabledReports = [];
  const recordsByEmployee = new Map();
  const recordsByLocation = new Map();
  const recordsBySku = new Map();
  const employeeNamesSet = new Set();
  const groupedLocations = Object.create(null);

  for (const [file, data] of reportCache.entries()) {
    if (!data || data.enabled !== true) continue;
    enabledReports.push({ file, data });

    const records = Array.isArray(data.records) ? data.records : [];
    for (const rec of records) {
      if (!rec || typeof rec !== "object") continue;
      const wrapped = Object.assign({ file }, rec);

      const employee = String(rec.employee_name ?? "").trim();
      if (employee) {
        employeeNamesSet.add(employee);
        pushMapArray(recordsByEmployee, employee, wrapped);
      }

      const hasLocBits =
        rec.LOC_NUM !== null &&
        rec.LOC_NUM !== undefined &&
        String(rec.LOC_NUM).trim() !== "" &&
        rec.loc_desc !== null &&
        rec.loc_desc !== undefined &&
        String(rec.loc_desc).trim() !== "";
      if (hasLocBits) {
        const locKey = `${rec.LOC_NUM} - ${rec.loc_desc}`;
        pushMapArray(recordsByLocation, locKey, wrapped);
      }

      const sku = String(rec.SKU ?? "").trim();
      if (sku) pushMapArray(recordsBySku, sku, wrapped);

      const area_desc = String(rec.area_desc ?? "").trim();
      const area_num = Number(rec.AREA_NUM);
      if (!area_desc || !Number.isFinite(area_num) || !hasLocBits) continue;

      if (!groupedLocations[area_desc]) {
        groupedLocations[area_desc] = {
          area_num,
          locations: new Set(),
        };
      } else if (area_num < groupedLocations[area_desc].area_num) {
        groupedLocations[area_desc].area_num = area_num;
      }

      groupedLocations[area_desc].locations.add(`${rec.LOC_NUM} - ${rec.loc_desc}`);
    }
  }

  const locationGroups = Object.entries(groupedLocations)
    .map(([area_desc, { area_num, locations }]) => ({
      area_desc,
      area_num,
      locations: Array.from(locations).sort(),
    }))
    .sort((a, b) => a.area_num - b.area_num)
    .map(({ area_desc, locations }) => ({ area_desc, locations }));

  enabledReports.sort((a, b) => String(a.file).localeCompare(String(b.file)));

  enabledDataIndex = {
    enabledReports,
    employeeNames: Array.from(employeeNamesSet).sort(),
    locationGroups,
    recordsByEmployee,
    recordsByLocation,
    recordsBySku,
  };
}

function scheduleEnabledDataIndexRebuild() {
  if (enabledIndexRebuildTimer) return;
  enabledIndexRebuildTimer = setTimeout(() => {
    enabledIndexRebuildTimer = null;
    rebuildEnabledDataIndex();
  }, 40);
}

let skuMaster = [];
const CUST_MASTER_FILE = path.join(JSON_DIR, "cust_master.json");

// --- Persistent location actions store (survives server restarts / export regeneration) ---
if (!fs.existsSync(REPORT_DIR)) fs.mkdirSync(REPORT_DIR, { recursive: true });

const LOCATION_ACTIONS_FILE = path.join(REPORT_DIR, "location_actions.json");
const REVIEW_STATUS_FILE = path.join(REPORT_DIR, "report_review_status.json");
const TABLET_PRESENCE_FILE = path.join(REPORT_DIR, "tablet_presence.json");
// Shape:
// {
//   "<file>": [
//     {
//       area_num,
//       loc_num,
//       action,      // "recount" | "question"
//       text,        // reason or question
//       timestamp,   // when the action was created
//       reply,       // optional: manager reply to a question
//       reply_at     // optional: when reply was added
//     },
//   ]
// }
let locationActionsStore = {};
let locationActionsStoreMtimeMs = -1;
let reviewStatusStore = {};
let reviewStatusStoreMtimeMs = -1;

let reportExportsBundleCache = null;
const REPORT_EXPORTS_BUNDLE_TTL_MS = 1500;

const reportEventClients = new Set();
let reportEventVersion = 0;

function sendReportEvent(res, eventName, payload) {
  res.write(`event: ${eventName}\n`);
  res.write(`data: ${JSON.stringify(payload || {})}\n\n`);
}

function notifyReportClients(type, payload = {}) {
  if (reportEventClients.size === 0) return;

  reportEventVersion += 1;
  const eventPayload = {
    type,
    version: reportEventVersion,
    timestamp: new Date().toISOString(),
    ...payload,
  };

  for (const res of Array.from(reportEventClients)) {
    try {
      sendReportEvent(res, "report-update", eventPayload);
    } catch {
      reportEventClients.delete(res);
    }
  }
}

function normalizeJsonText(raw) {
  return String(raw || "")
    .replace(/^\uFEFF/, "")
    .replace(/\u0000/g, "")
    .trim();
}

function readJsonFile(filePath) {
  const raw = normalizeJsonText(fs.readFileSync(filePath, "utf8"));
  return JSON.parse(raw);
}

function getFileVersionFromStat(stat) {
  return `${Number(stat?.mtimeMs || 0)}:${Number(stat?.size || 0)}`;
}

function loadLocationActionsFromDisk() {
  try {
    if (!fs.existsSync(LOCATION_ACTIONS_FILE)) {
      locationActionsStore = {};
      locationActionsStoreMtimeMs = -1;
      return;
    }
    const raw = normalizeJsonText(
      fs.readFileSync(LOCATION_ACTIONS_FILE, "utf8"),
    );
    if (!raw) {
      locationActionsStore = {};
      locationActionsStoreMtimeMs = fs.statSync(LOCATION_ACTIONS_FILE).mtimeMs;
      return;
    }
    const parsed = JSON.parse(raw);
    if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
      locationActionsStore = parsed;
      locationActionsStoreMtimeMs = fs.statSync(LOCATION_ACTIONS_FILE).mtimeMs;
    } else {
      locationActionsStore = {};
      locationActionsStoreMtimeMs = fs.statSync(LOCATION_ACTIONS_FILE).mtimeMs;
    }
  } catch (e) {
    console.warn("Failed to load location_actions.json:", e.message);
    locationActionsStore = {};
    locationActionsStoreMtimeMs = -1;
  }
}

function saveLocationActionsToDisk() {
  const tmp = LOCATION_ACTIONS_FILE + ".tmp";
  fs.writeFileSync(tmp, JSON.stringify(locationActionsStore, null, 2), "utf8");
  fs.renameSync(tmp, LOCATION_ACTIONS_FILE);
  invalidateReportExportsBundleCache();
  notifyReportClients("location-actions", { file: path.basename(LOCATION_ACTIONS_FILE) });
  try {
    locationActionsStoreMtimeMs = fs.statSync(LOCATION_ACTIONS_FILE).mtimeMs;
  } catch {
    locationActionsStoreMtimeMs = Date.now();
  }
}

function syncLocationActionsStoreFromDiskIfChanged() {
  let diskMtimeMs = -1;
  try {
    if (fs.existsSync(LOCATION_ACTIONS_FILE)) {
      diskMtimeMs = fs.statSync(LOCATION_ACTIONS_FILE).mtimeMs;
    }
  } catch {
    diskMtimeMs = -1;
  }

  if (diskMtimeMs < 0) {
    if (Object.keys(locationActionsStore).length > 0) {
      locationActionsStore = {};
      invalidateReportExportsBundleCache();
    }
    locationActionsStoreMtimeMs = -1;
    return;
  }

  if (locationActionsStoreMtimeMs === diskMtimeMs) return;
  loadLocationActionsFromDisk();
  invalidateReportExportsBundleCache();
}

function getStoredActionsForFile(file) {
  syncLocationActionsStoreFromDiskIfChanged();
  const arr = locationActionsStore[file];
  return Array.isArray(arr) ? arr : [];
}

function loadReviewStatusFromDisk() {
  try {
    if (!fs.existsSync(REVIEW_STATUS_FILE)) {
      reviewStatusStore = {};
      reviewStatusStoreMtimeMs = -1;
      return;
    }
    const raw = normalizeJsonText(fs.readFileSync(REVIEW_STATUS_FILE, "utf8"));
    if (!raw) {
      reviewStatusStore = {};
      reviewStatusStoreMtimeMs = fs.statSync(REVIEW_STATUS_FILE).mtimeMs;
      return;
    }

    const parsed = JSON.parse(raw);
    if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
      reviewStatusStore = parsed;
    } else {
      reviewStatusStore = {};
    }
    reviewStatusStoreMtimeMs = fs.statSync(REVIEW_STATUS_FILE).mtimeMs;
  } catch (e) {
    console.warn("Failed to load report_review_status.json:", e.message);
    reviewStatusStore = {};
    reviewStatusStoreMtimeMs = -1;
  }
}

function saveReviewStatusToDisk() {
  const tmp = REVIEW_STATUS_FILE + ".tmp";
  fs.writeFileSync(tmp, JSON.stringify(reviewStatusStore, null, 2), "utf8");
  fs.renameSync(tmp, REVIEW_STATUS_FILE);
  invalidateReportExportsBundleCache();
  notifyReportClients("review-status", { file: path.basename(REVIEW_STATUS_FILE) });
  try {
    reviewStatusStoreMtimeMs = fs.statSync(REVIEW_STATUS_FILE).mtimeMs;
  } catch {
    reviewStatusStoreMtimeMs = Date.now();
  }
}

function syncReviewStatusStoreFromDiskIfChanged() {
  let diskMtimeMs = -1;
  try {
    if (fs.existsSync(REVIEW_STATUS_FILE)) {
      diskMtimeMs = fs.statSync(REVIEW_STATUS_FILE).mtimeMs;
    }
  } catch {
    diskMtimeMs = -1;
  }

  if (diskMtimeMs < 0) {
    if (Object.keys(reviewStatusStore).length > 0) {
      reviewStatusStore = {};
      invalidateReportExportsBundleCache();
    }
    reviewStatusStoreMtimeMs = -1;
    return;
  }

  if (reviewStatusStoreMtimeMs === diskMtimeMs) return;
  loadReviewStatusFromDisk();
  invalidateReportExportsBundleCache();
}

function getReviewStatusForFile(file) {
  syncReviewStatusStoreFromDiskIfChanged();
  const item = reviewStatusStore[file];
  return item && typeof item === "object" ? item : null;
}

function applyReviewedStateForFile(file, reviewed, reviewed_at) {
  const data = reportExportCache.get(file);
  if (!data) return false;

  const existingStatus =
    reviewStatusStore[file] && typeof reviewStatusStore[file] === "object"
      ? reviewStatusStore[file]
      : null;
  const seen_at =
    existingStatus && typeof existingStatus.seen_at === "string"
      ? existingStatus.seen_at
      : typeof data.seen_at === "string"
        ? data.seen_at
        : "";

  data.reviewed = reviewed;
  if (reviewed) {
    data.reviewed_at = reviewed_at;
  }

  reviewStatusStore[file] = {
    reviewed,
    reviewed_at: reviewed ? reviewed_at : data.reviewed_at || "",
    seen_at,
  };

  reportExportCache.set(file, data);
  return true;
}

function applySeenStateForFile(file, seen_at) {
  const data = reportExportCache.get(file);
  if (!data) return false;

  const nextSeenMs = Date.parse(String(seen_at || ""));
  const currentDataSeenAt =
    typeof data.seen_at === "string" ? data.seen_at : "";
  const currentDataSeenMs = Date.parse(currentDataSeenAt);
  if (
    !Number.isFinite(currentDataSeenMs) ||
    (Number.isFinite(nextSeenMs) && nextSeenMs >= currentDataSeenMs)
  ) {
    data.seen_at = seen_at;
  }

  const existingStatus =
    reviewStatusStore[file] && typeof reviewStatusStore[file] === "object"
      ? reviewStatusStore[file]
      : null;
  const currentStatusSeenAt =
    existingStatus && typeof existingStatus.seen_at === "string"
      ? existingStatus.seen_at
      : "";
  const currentStatusSeenMs = Date.parse(currentStatusSeenAt);
  const mergedSeenAt =
    !currentStatusSeenAt ||
    !Number.isFinite(currentStatusSeenMs) ||
    (Number.isFinite(nextSeenMs) && nextSeenMs >= currentStatusSeenMs)
      ? seen_at
      : currentStatusSeenAt;

  reviewStatusStore[file] = {
    reviewed: existingStatus ? existingStatus.reviewed === true : data.reviewed === true,
    reviewed_at:
      existingStatus && typeof existingStatus.reviewed_at === "string"
        ? existingStatus.reviewed_at
        : data.reviewed_at || "",
    seen_at: mergedSeenAt,
  };

  reportExportCache.set(file, data);
  return true;
}

function invalidateReportExportsBundleCache() {
  reportExportsBundleCache = null;
}

function saveTabletPresenceToDisk(payload) {
  const tmp = TABLET_PRESENCE_FILE + ".tmp";
  fs.writeFileSync(tmp, JSON.stringify(payload, null, 2), "utf8");
  fs.renameSync(tmp, TABLET_PRESENCE_FILE);
}

function mergeLocationActions(baseArr, storedArr, opts = {}) {
  const minTimestampMs = Number(opts.minTimestampMs || 0);
  // Dedupe by (loc_num, action, timestamp, text) while preserving reply fields.
  // Important: If a later version of the same action gains a reply, we must
  // keep that reply so the UI can show it under the Questions tab.

  const map = new Map();

  const norm = (a) => {
    if (!a || typeof a !== "object") return null;
    const loc_num = String(a.loc_num ?? "").trim();
    const action = String(a.action ?? a.type ?? "")
      .trim()
      .toLowerCase();
    const text = String(a.text ?? a.message ?? a.question ?? "");
    const timestamp = String(a.timestamp ?? a.ts ?? "");
    const reply = typeof a.reply === "string" ? a.reply : undefined;
    const reply_at = typeof a.reply_at === "string" ? a.reply_at : undefined;

    if (!loc_num || !action) return null;

    return {
      area_num: a.area_num,
      loc_num,
      action,
      text,
      timestamp,
      reply,
      reply_at,
    };
  };

  const add = (a) => {
    const n = norm(a);
    if (!n) return;

    // Optional freshness guard: ignore actions older than the export file.
    if (minTimestampMs > 0) {
      const tsMs = Date.parse(String(n.timestamp || ""));
      if (!Number.isFinite(tsMs) || tsMs < minTimestampMs) return;
    }

    const key = `${n.loc_num}::${n.action}::${n.timestamp}::${n.text}`;
    const prev = map.get(key);

    if (!prev) {
      map.set(key, n);
      return;
    }

    // Merge: prefer reply/reply_at if either version has it.
    if (typeof prev.reply !== "string" || !prev.reply.trim()) {
      if (typeof n.reply === "string" && n.reply.trim()) prev.reply = n.reply;
    }

    if (typeof prev.reply_at !== "string" || !prev.reply_at.trim()) {
      if (typeof n.reply_at === "string" && n.reply_at.trim())
        prev.reply_at = n.reply_at;
    }

    // If area_num is missing on the older one but present on the newer, fill it.
    if ((prev.area_num === undefined || prev.area_num === null) && n.area_num) {
      prev.area_num = n.area_num;
    }
  };

  (Array.isArray(baseArr) ? baseArr : []).forEach(add);
  (Array.isArray(storedArr) ? storedArr : []).forEach(add);

  // Return in a stable order: by loc_num, then timestamp, then action.
  const out = Array.from(map.values());
  out.sort((a, b) => {
    const la = String(a.loc_num).localeCompare(String(b.loc_num));
    if (la) return la;
    const ta = String(a.timestamp || "").localeCompare(String(b.timestamp || ""));
    if (ta) return ta;
    return String(a.action).localeCompare(String(b.action));
  });

  return out;
}

/**
 * Preload every .json in JSON_DIR into reportCache
 */
function isTrackedAuditReportFile(filename) {
  const lower = String(filename || "").toLowerCase();
  if (!lower.endsWith(".json")) return false;
  return ![
    "chatlog.json",
    "cust_master.json",
    "employees.json",
    "yesnooption.json",
  ].includes(lower);
}

function reloadAuditReportFile(filename, attempt = 0) {
  if (!isTrackedAuditReportFile(filename)) return;

  const filePath = path.join(JSON_DIR, filename);
  if (!fs.existsSync(filePath)) {
    reportCache.delete(filename);
    auditReportFileVersions.delete(filename);
    console.log(`Removed ${filename} from cache`);
    scheduleEnabledDataIndexRebuild();
    return;
  }

  try {
    const parsed = readJsonFile(filePath);
    reportCache.set(filename, parsed);
    const stat = fs.statSync(filePath);
    auditReportFileVersions.set(filename, getFileVersionFromStat(stat));
    console.log(`Reloaded ${filename} into cache`);
    scheduleEnabledDataIndexRebuild();
  } catch (err) {
    // Export writes can be observed mid-update; retry before giving up.
    if (attempt < 3) {
      setTimeout(() => reloadAuditReportFile(filename, attempt + 1), 60 * (attempt + 1));
      return;
    }
    console.warn(`Failed to reload ${filename}: ${err.message}`);
  }
}

function syncAuditReportCacheFromDisk(opts = {}) {
  const force = opts.force === true;
  const now = Date.now();
  if (!force && now - lastAuditReportSyncMs < AUDIT_REPORT_SYNC_COOLDOWN_MS) {
    return;
  }
  lastAuditReportSyncMs = now;

  let files = [];
  try {
    files = fs.readdirSync(JSON_DIR).filter((f) => isTrackedAuditReportFile(f));
  } catch (err) {
    console.warn(`Failed to read JSON_DIR for audit sync: ${err.message}`);
    return;
  }

  const seen = new Set(files);

  for (const file of files) {
    const filePath = path.join(JSON_DIR, file);
    let stat;
    try {
      stat = fs.statSync(filePath);
    } catch {
      continue;
    }

    const nextVersion = getFileVersionFromStat(stat);
    const prevVersion = auditReportFileVersions.get(file);
    if (!reportCache.has(file) || prevVersion !== nextVersion) {
      reloadAuditReportFile(file);
    }
  }

  let removedAny = false;
  for (const cachedFile of Array.from(reportCache.keys())) {
    if (seen.has(cachedFile)) continue;
    reportCache.delete(cachedFile);
    auditReportFileVersions.delete(cachedFile);
    removedAny = true;
    console.log(`Removed ${cachedFile} from cache`);
  }

  if (removedAny) scheduleEnabledDataIndexRebuild();
}

function preloadReports() {
  const files = fs
    .readdirSync(JSON_DIR)
    .filter((f) => isTrackedAuditReportFile(f));

  files.forEach((f) => {
    try {
      reloadAuditReportFile(f);
    } catch (err) {
      console.warn(`Skipping invalid JSON ${f}: ${err.message}`);
    }
  });

  rebuildEnabledDataIndex();
  console.log(`Preloaded ${reportCache.size} JSON files into memory`);
}

// Watch for changes in JSON_DIR and reload individual files
fs.watch(JSON_DIR, (event, filename) => {
  if (!filename) return;
  reloadAuditReportFile(filename);
});

function preloadCustMaster() {
  try {
    skuMaster = readJsonFile(CUST_MASTER_FILE);
    console.log(`Preloaded ${skuMaster.length} SKUs into memory`);
  } catch (err) {
    console.warn("Failed to preload cust_master.json:", err.message);
  }
}

fs.watchFile(CUST_MASTER_FILE, () => {
  console.log("cust_master.json changed â€” reloading");
  preloadCustMaster();
});

function preloadReportExports() {
  if (!fs.existsSync(REPORT_DIR)) {
    console.warn(`REPORT_DIR does not exist: ${REPORT_DIR}`);
    return;
  }

  const files = fs
    .readdirSync(REPORT_DIR)
    .filter((f) => f.toLowerCase().endsWith(".json"));

  files.forEach((f) => reloadReportExportFile(f));

  console.log(
    `Preloaded ${reportExportCache.size} report-export JSON files into memory`,
  );
}

function reloadReportExportFile(filename, attempt = 0) {
  if (!filename || !filename.toLowerCase().endsWith(".json")) return;

  const filePath = path.join(REPORT_DIR, filename);
  if (!fs.existsSync(filePath)) {
    reportExportCache.delete(filename);
    reportExportFileVersions.delete(filename);
    invalidateReportExportsBundleCache();
    notifyReportClients("report-export-removed", { file: filename });
    console.log(`Removed report export ${filename} from cache`);
    return;
  }

  try {
    const data = readJsonFile(filePath);
    reportExportCache.set(filename, data);
    const stat = fs.statSync(filePath);
    reportExportFileVersions.set(filename, getFileVersionFromStat(stat));
    invalidateReportExportsBundleCache();
    notifyReportClients("report-export", { file: filename });
    console.log(`Reloaded report export ${filename} into cache`);
  } catch (err) {
    if (attempt < 3) {
      setTimeout(
        () => reloadReportExportFile(filename, attempt + 1),
        60 * (attempt + 1),
      );
      return;
    }
    console.warn(`Failed to reload report export ${filename}: ${err.message}`);
  }
}

function syncReportExportCacheFromDisk(opts = {}) {
  if (!fs.existsSync(REPORT_DIR)) return;

  const force = opts.force === true;
  const now = Date.now();
  if (!force && now - lastReportExportSyncMs < REPORT_EXPORT_SYNC_COOLDOWN_MS) {
    return;
  }
  lastReportExportSyncMs = now;

  let files = [];
  try {
    files = fs
      .readdirSync(REPORT_DIR)
      .filter((f) => String(f).toLowerCase().endsWith(".json"));
  } catch (err) {
    console.warn(`Failed to read REPORT_DIR for sync: ${err.message}`);
    return;
  }

  const seen = new Set(files);

  for (const file of files) {
    const filePath = path.join(REPORT_DIR, file);
    let stat;
    try {
      stat = fs.statSync(filePath);
    } catch {
      continue;
    }

    const nextVersion = getFileVersionFromStat(stat);
    const prevVersion = reportExportFileVersions.get(file);
    if (!reportExportCache.has(file) || prevVersion !== nextVersion) {
      reloadReportExportFile(file);
    }
  }

  for (const cachedFile of Array.from(reportExportCache.keys())) {
    if (seen.has(cachedFile)) continue;
    reportExportCache.delete(cachedFile);
    reportExportFileVersions.delete(cachedFile);
    invalidateReportExportsBundleCache();
    console.log(`Removed report export ${cachedFile} from cache`);
  }
}

// Watch for changes in REPORT_DIR and reload individual files
if (fs.existsSync(REPORT_DIR)) {
  fs.watch(REPORT_DIR, (event, filename) => {
    if (!filename) return;
    reloadReportExportFile(filename);
  });
}

// --- Chat log (Report-Site/chatlog.json) ---
// Canonical format:
// {
//   "messages": [
//     {
//       "id": "...",
//       "timestamp": "...",
//       "user": "...",
//       "sender_side": "supervisor" | "tablet",
//       "message": "...",
//       "delivered_to_supervisor_at": "...",
//       "delivered_to_tablet_at": "...",
//       "read_by_supervisor_at": "...",
//       "read_by_tablet_at": "..."
//     }
//   ]
// }
const CHATLOG_FILE = path.join(REPORT_DIR, "chatlog.json");
let chatLog = { messages: [] };
const CHAT_SIDE_SUPERVISOR = "supervisor";
const CHAT_SIDE_TABLET = "tablet";

function normalizeJsonText(raw) {
  return String(raw || "")
    .replace(/^\uFEFF/, "")
    .replace(/\u0000/g, "")
    .trim();
}

function generateChatMessageId() {
  return `${Date.now()}_${Math.random().toString(16).slice(2)}`;
}

function normalizeExplicitChatSide(side) {
  const raw = String(side ?? "")
    .trim()
    .toLowerCase();
  if (raw === CHAT_SIDE_SUPERVISOR) return CHAT_SIDE_SUPERVISOR;
  if (raw === CHAT_SIDE_TABLET) return CHAT_SIDE_TABLET;
  return "";
}

function normalizeChatSide(side, user) {
  const explicit = normalizeExplicitChatSide(side);
  if (explicit) return explicit;

  const userName = String(user ?? "").trim().toLowerCase();
  if (userName === "store manager") return CHAT_SIDE_TABLET;
  if (userName) return CHAT_SIDE_SUPERVISOR;
  return CHAT_SIDE_TABLET;
}

function nullIfBlank(value) {
  const trimmed = String(value ?? "").trim();
  return trimmed || null;
}

function normalizeChatMessage(m) {
  // Accept either {user,message,timestamp} or legacy {from,text,timestamp}
  const timestamp =
    String(m?.timestamp ?? "").trim() || new Date().toISOString();
  const user = String(m?.user ?? m?.from ?? "").trim();
  const message = String(m?.message ?? m?.text ?? "").trim();

  if (!user || !message) return null;

  const senderSide = normalizeChatSide(m?.sender_side, user);

  return {
    id: String(m?.id ?? m?.message_id ?? "").trim() || generateChatMessageId(),
    timestamp,
    user,
    sender_side: senderSide,
    message,
    delivered_to_supervisor_at: nullIfBlank(m?.delivered_to_supervisor_at),
    delivered_to_tablet_at: nullIfBlank(m?.delivered_to_tablet_at),
    read_by_supervisor_at: nullIfBlank(m?.read_by_supervisor_at),
    read_by_tablet_at: nullIfBlank(m?.read_by_tablet_at),
  };
}

function loadChatLogFromDisk() {
  try {
    if (!fs.existsSync(REPORT_DIR)) return;

    if (!fs.existsSync(CHATLOG_FILE)) {
      chatLog = { messages: [] };
      saveChatLogToDisk();
      return;
    }

    const raw = normalizeJsonText(fs.readFileSync(CHATLOG_FILE, "utf8"));
    if (!raw) {
      chatLog = { messages: [] };
      saveChatLogToDisk();
      return;
    }

    const parsed = JSON.parse(raw);

    let msgs = [];
    if (Array.isArray(parsed)) {
      msgs = parsed;
    } else if (
      parsed &&
      typeof parsed === "object" &&
      Array.isArray(parsed.messages)
    ) {
      msgs = parsed.messages;
    }

    const normalized = [];
    for (const m of msgs) {
      const nm = normalizeChatMessage(m);
      if (nm) normalized.push(nm);
    }

    chatLog = { messages: normalized };
  } catch (e) {
    console.warn("Failed to load chatlog.json:", e.message);
    chatLog = { messages: [] };
  }
}

function saveChatLogToDisk() {
  const tmp = CHATLOG_FILE + ".tmp";
  fs.writeFileSync(tmp, JSON.stringify(chatLog, null, 2), "utf8");
  fs.renameSync(tmp, CHATLOG_FILE);
  notifyReportClients("chatlog", { file: path.basename(CHATLOG_FILE) });
}

function ensureChatLogSizeLimit() {
  if (!Array.isArray(chatLog.messages)) chatLog.messages = [];
  if (chatLog.messages.length > 2000) {
    chatLog.messages = chatLog.messages.slice(chatLog.messages.length - 2000);
  }
}

function buildPostedChatMessage(body) {
  const timestamp =
    String(body?.timestamp ?? "").trim() || new Date().toISOString();
  const user = String(body?.user ?? body?.from ?? "Store Manager").trim();
  const message = String(body?.message ?? body?.text ?? "").trim();
  const senderSide = normalizeChatSide(body?.sender_side, user);

  if (!user || !message) return null;

  const msg = normalizeChatMessage({
    id: body?.id,
    timestamp,
    user,
    sender_side: senderSide,
    message,
    delivered_to_supervisor_at: body?.delivered_to_supervisor_at,
    delivered_to_tablet_at: body?.delivered_to_tablet_at,
    read_by_supervisor_at: body?.read_by_supervisor_at,
    read_by_tablet_at: body?.read_by_tablet_at,
  });

  if (!msg) return null;

  if (senderSide === CHAT_SIDE_SUPERVISOR) {
    if (!msg.delivered_to_supervisor_at) {
      msg.delivered_to_supervisor_at = timestamp;
    }
    if (!msg.read_by_supervisor_at) {
      msg.read_by_supervisor_at = timestamp;
    }
  } else {
    if (!msg.delivered_to_tablet_at) {
      msg.delivered_to_tablet_at = timestamp;
    }
    if (!msg.read_by_tablet_at) {
      msg.read_by_tablet_at = timestamp;
    }
  }

  return msg;
}

function updateChatReceiptStatus(side, status) {
  const receiverSide = normalizeExplicitChatSide(side);
  const normalizedStatus = String(status ?? "")
    .trim()
    .toLowerCase();

  if (
    receiverSide !== CHAT_SIDE_SUPERVISOR &&
    receiverSide !== CHAT_SIDE_TABLET
  ) {
    return { ok: false, error: "Missing side" };
  }

  if (normalizedStatus !== "delivered" && normalizedStatus !== "read") {
    return { ok: false, error: "Invalid status" };
  }

  if (!Array.isArray(chatLog.messages)) chatLog.messages = [];

  let changed = false;
  const now = new Date().toISOString();

  for (const row of chatLog.messages) {
    if (!row || typeof row !== "object") continue;

    const senderSide = normalizeChatSide(row.sender_side, row.user);
    row.sender_side = senderSide;

    if (senderSide === receiverSide) continue;

    if (receiverSide === CHAT_SIDE_SUPERVISOR) {
      if (!row.delivered_to_supervisor_at) {
        row.delivered_to_supervisor_at = now;
        changed = true;
      }
      if (normalizedStatus === "read" && !row.read_by_supervisor_at) {
        row.read_by_supervisor_at = now;
        changed = true;
      }
    } else {
      if (!row.delivered_to_tablet_at) {
        row.delivered_to_tablet_at = now;
        changed = true;
      }
      if (normalizedStatus === "read" && !row.read_by_tablet_at) {
        row.read_by_tablet_at = now;
        changed = true;
      }
    }
  }

  if (changed) {
    ensureChatLogSizeLimit();
    saveChatLogToDisk();
  }

  return { ok: true, changed };
}

function handleGetChatLog(req, res) {
  res.json(chatLog);
}

function handlePostChatLog(req, res) {
  const msg = buildPostedChatMessage(req.body);

  if (!msg?.user) return res.status(400).json({ error: "Missing user" });
  if (!msg?.message) return res.status(400).json({ error: "Missing message" });

  if (!Array.isArray(chatLog.messages)) chatLog.messages = [];
  chatLog.messages.push(msg);
  ensureChatLogSizeLimit();

  try {
    saveChatLogToDisk();
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }

  res.json({ success: true, message: msg });
}

function handlePostChatReceipts(req, res) {
  try {
    const result = updateChatReceiptStatus(req.body?.side, req.body?.status);
    if (!result.ok) {
      return res.status(400).json({ error: result.error });
    }

    res.json({ success: true, changed: !!result.changed });
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
}

// Reload chat in memory if edited externally
if (fs.existsSync(REPORT_DIR)) {
  fs.watch(REPORT_DIR, (event, filename) => {
    if (!filename) return;
    if (String(filename).toLowerCase() === "chatlog.json") {
      loadChatLogFromDisk();
    }
  });
}

// Preload at startup
preloadReports();
preloadReportExports();
preloadCustMaster();
loadChatLogFromDisk();
loadLocationActionsFromDisk();
loadReviewStatusFromDisk();

// allow up to 10â€¯MB of JSON
app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ limit: "10mb", extended: true }));

// serve static assets
app.use(express.static(path.join(__dirname, "public")));

// server.js (near top)
const EMP_FILE = path.join(JSON_DIR, "employees.json");

function loadEmployees() {
  if (fs.existsSync(EMP_FILE)) {
    try {
      return readJsonFile(EMP_FILE);
    } catch {
      return {};
    }
  }
  return {};
}

function saveEmployees(empData) {
  fs.writeFileSync(EMP_FILE, JSON.stringify(empData, null, 2), "utf8");
}

/**
 * Helper: returns only those cached JSON entries
 * whose parsed object has enabled === true.
 *
 * callback signature: (err, [ { file, data }, â€¦ ])
 */
function loadEnabledReports(callback) {
  try {
    syncAuditReportCacheFromDisk();
    const results = enabledDataIndex.enabledReports;
    // simulate async
    process.nextTick(() => callback(null, results));
  } catch (err) {
    process.nextTick(() => callback(err));
  }
}
// Lookup a single SKU from cust_master.json
app.get("/api/sku/:sku", (req, res) => {
  const sku = String(req.params.sku);
  const match = skuMaster.find((item) => String(item.SKU) === sku);
  if (match) return res.json(match);
  res.status(404).json({ error: "SKU not found" });
});

// â€”â€”â€” list enabled JSON filenames â€”â€”â€”
app.get("/api/reports", (req, res) => {
  loadEnabledReports((err, reps) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(reps.map((r) => r.file));
  });
});

// serve YesNoOption.json from the JSON_DIR
app.get("/api/YesNoOption.json", (req, res) => {
  res.sendFile(path.join(JSON_DIR, "YesNoOption.json"));
});

// serve cust_master.json from the JSON_DIR
app.get("/api/cust_master.json", (req, res) => {
  res.sendFile(path.join(JSON_DIR, "cust_master.json"));
});

// â€”â€”â€” list all employees across enabled reports â€”â€”â€”
app.get("/api/employees", (req, res) => {
  try {
    syncAuditReportCacheFromDisk();
    const names = enabledDataIndex.employeeNames;
    const empData = loadEmployees();
    let changed = false;

    for (const n of names) {
      if (empData[n] !== false) {
        empData[n] = false;
        changed = true;
      }
    }
    if (changed) saveEmployees(empData);

    const out = Object.keys(empData)
      .sort()
      .map((n) => ({ name: n, completed: empData[n] }));
    res.json(out);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// â€”â€”â€” list all locations across enabled reports â€”â€”â€”
// server.js

app.get("/api/locations", (req, res) => {
  syncAuditReportCacheFromDisk();
  res.json(enabledDataIndex.locationGroups);
});

// near the top, after your other route definitions
app.get("/ping", (req, res) => {
  res.sendStatus(200);
});

app.get("/api/report-events", (req, res) => {
  res.set({
    "Content-Type": "text/event-stream",
    "Cache-Control": "no-cache, no-transform",
    Connection: "keep-alive",
    "X-Accel-Buffering": "no",
  });
  res.flushHeaders?.();

  reportEventClients.add(res);
  sendReportEvent(res, "connected", {
    type: "connected",
    version: reportEventVersion,
    timestamp: new Date().toISOString(),
  });

  const heartbeat = setInterval(() => {
    try {
      sendReportEvent(res, "heartbeat", {
        type: "heartbeat",
        version: reportEventVersion,
        timestamp: new Date().toISOString(),
      });
    } catch {
      clearInterval(heartbeat);
      reportEventClients.delete(res);
    }
  }, 25000);

  req.on("close", () => {
    clearInterval(heartbeat);
    reportEventClients.delete(res);
  });
});

app.post("/api/tablet-presence/heartbeat", (req, res) => {
  const nowIso = new Date().toISOString();
  const remoteAddress =
    req.headers["x-forwarded-for"] ||
    req.socket?.remoteAddress ||
    req.ip ||
    "";
  const normalizeStringList = (value) => {
    if (!Array.isArray(value)) return [];
    return Array.from(
      new Set(
        value
          .map((v) => String(v ?? "").trim())
          .filter(Boolean),
      ),
    );
  };
  const currentViewFiles = normalizeStringList(req.body?.current_view_files);
  const currentViewAreaNums = normalizeStringList(req.body?.current_view_area_nums);

  const payload = {
    device: "tablet",
    page: "report",
    last_heartbeat_at: nowIso,
    client_timestamp:
      typeof req.body?.client_timestamp === "string"
        ? req.body.client_timestamp
        : "",
    visibility_state:
      typeof req.body?.visibility_state === "string"
        ? req.body.visibility_state
        : "",
    browser_online: req.body?.browser_online === true,
    server_connection_state:
      typeof req.body?.server_connection_state === "string"
        ? req.body.server_connection_state
        : "",
    current_view_mode:
      typeof req.body?.current_view_mode === "string"
        ? req.body.current_view_mode
        : "",
    current_view_files: currentViewFiles,
    current_view_area_nums: currentViewAreaNums,
    current_view_file: currentViewFiles.length > 0 ? currentViewFiles[0] : "",
    current_view_area_num:
      currentViewAreaNums.length > 0 ? currentViewAreaNums[0] : "",
    user_agent: String(req.headers["user-agent"] || ""),
    remote_address: Array.isArray(remoteAddress)
      ? String(remoteAddress[0] || "")
      : String(remoteAddress || ""),
  };

  try {
    saveTabletPresenceToDisk(payload);
    return res.json({ success: true, last_heartbeat_at: nowIso });
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
});

app.get("/api/tablet-presence", (req, res) => {
  try {
    if (!fs.existsSync(TABLET_PRESENCE_FILE)) {
      return res.json({
        device: "tablet",
        page: "report",
        last_heartbeat_at: "",
      });
    }

    return res.json(readJsonFile(TABLET_PRESENCE_FILE));
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
});

app.get("/api/report-exports-test", (req, res) => {
  syncReportExportCacheFromDisk();
  res.json({ ok: true, count: reportExportCache.size });
});

// â€”â€”â€” fetch records filtered by employee, location, or SKU (only from enabled) â€”â€”â€”
app.get("/api/records", (req, res) => {
  syncAuditReportCacheFromDisk();
  const { employee, location, sku } = req.query;
  if (!employee && !location && !sku) {
    return res
      .status(400)
      .json({ error: "Must specify ?employee=â€¦ or ?location=â€¦ or ?sku=â€¦" });
  }

  try {
    if (employee) {
      return res.json(enabledDataIndex.recordsByEmployee.get(String(employee)) || []);
    }
    if (location) {
      return res.json(enabledDataIndex.recordsByLocation.get(String(location)) || []);
    }
    if (sku) {
      return res.json(enabledDataIndex.recordsBySku.get(String(sku)) || []);
    }
    return res.json([]);
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
});

// List available area exports (EXCLUDES chatlog.json)
app.get("/api/report-exports", (req, res) => {
  syncReportExportCacheFromDisk();
  syncReviewStatusStoreFromDiskIfChanged();
  const reviewByFile = reviewStatusStore;
  const list = Array.from(reportExportCache.entries())
    .filter(([file, data]) => {
      if (!data || !data.area_num) return false;
      if (String(file).toLowerCase() === "chatlog.json") return false;
      return true;
    })
    .map(([file, data]) => {
      const status =
        reviewByFile[file] && typeof reviewByFile[file] === "object"
          ? reviewByFile[file]
          : null;
      return {
        file,
        area_num: data.area_num,
        area_desc: data.area_desc || "",
        location_count: Array.isArray(data.locations) ? data.locations.length : 0,
        reviewed: status ? status.reviewed === true : data.reviewed === true,
        reviewed_at:
          status && typeof status.reviewed_at === "string"
            ? status.reviewed_at
            : data.reviewed_at || "",
        seen_at:
          status && typeof status.seen_at === "string"
            ? status.seen_at
            : data.seen_at || "",
      };
    })
    .sort((a, b) => String(a.area_num).localeCompare(String(b.area_num)));

  res.json(list);
});

function buildMergedReportExportForResponse(file, base, opts = {}) {
  if (!base) return null;

  const storedByFile =
    opts.storedActionsByFile && typeof opts.storedActionsByFile === "object"
      ? opts.storedActionsByFile
      : null;
  const reviewByFile =
    opts.reviewStatusByFile && typeof opts.reviewStatusByFile === "object"
      ? opts.reviewStatusByFile
      : null;

  const stored = Array.isArray(storedByFile?.[file])
    ? storedByFile[file]
    : getStoredActionsForFile(file);
  const reviewStatus =
    (reviewByFile?.[file] && typeof reviewByFile[file] === "object"
      ? reviewByFile[file]
      : null) || getReviewStatusForFile(file);

  const locationActions = Array.isArray(base.location_actions)
    ? base.location_actions
    : [];
  const legacyLocationActions = Array.isArray(base.locationActions)
    ? base.locationActions
    : [];
  const legacyActions = Array.isArray(base.actions) ? base.actions : [];
  const needsActionMerge =
    stored.length > 0 ||
    legacyLocationActions.length > 0 ||
    legacyActions.length > 0;
  const needsReviewOverlay = reviewStatus !== null;

  if (!needsActionMerge && !needsReviewOverlay) {
    return base;
  }

  const out = { ...base };
  if (needsActionMerge) {
    out.location_actions = mergeLocationActions(
      locationActions.concat(legacyLocationActions, legacyActions),
      stored,
    );
  }
  if (needsReviewOverlay) {
    out.reviewed = reviewStatus.reviewed === true;
    if (typeof reviewStatus.reviewed_at === "string") {
      out.reviewed_at = reviewStatus.reviewed_at;
    }
    if (typeof reviewStatus.seen_at === "string") {
      out.seen_at = reviewStatus.seen_at;
    }
  }
  return out;
}

// Bundled list for fast report home-screen load/refresh:
// one request returns list metadata + per-file JSON content.
app.get("/api/report-exports-bundle", (req, res) => {
  syncReportExportCacheFromDisk();
  const now = Date.now();
  if (
    reportExportsBundleCache &&
    now - reportExportsBundleCache.ts < REPORT_EXPORTS_BUNDLE_TTL_MS
  ) {
    return res.json(reportExportsBundleCache.items);
  }

  syncLocationActionsStoreFromDiskIfChanged();
  syncReviewStatusStoreFromDiskIfChanged();

  const items = Array.from(reportExportCache.entries())
    .filter(([file, data]) => {
      if (!data || !data.area_num) return false;
      if (String(file).toLowerCase() === "chatlog.json") return false;
      return true;
    })
    .map(([file, data]) => {
      const merged = buildMergedReportExportForResponse(file, data, {
        storedActionsByFile: locationActionsStore,
        reviewStatusByFile: reviewStatusStore,
      });
      return {
        file,
        area_num: merged?.area_num ?? data.area_num,
        area_desc: merged?.area_desc ?? data.area_desc ?? "",
        location_count: Array.isArray(merged?.locations)
          ? merged.locations.length
          : Array.isArray(data.locations)
            ? data.locations.length
            : 0,
        data: merged || data,
      };
    })
    .sort((a, b) => String(a.area_num).localeCompare(String(b.area_num)));

  reportExportsBundleCache = { ts: now, items };
  res.json(items);
});

// --------------------
// Chatlog API
// GET returns { messages: [...] }
// POST appends a message and persists to Report-Site/chatlog.json
// POST /receipts marks incoming messages delivered or read for one side
// --------------------

app.get("/api/chatlog", handleGetChatLog);
app.post("/api/chatlog", handlePostChatLog);
app.post("/api/chatlog/receipts", handlePostChatReceipts);

// Fetch one area export by filename (e.g. 40051.json)
app.get("/api/report-exports/:file", (req, res) => {
  syncReportExportCacheFromDisk();
  const file = req.params.file;
  const base = reportExportCache.get(file);
  if (!base) return res.status(404).json({ error: "Report export not found" });
  const out = buildMergedReportExportForResponse(file, base);
  res.json(out);
});

// â”€â”€â”€ POST location actions (recount / question) â”€â”€â”€
app.post("/api/report-exports/:file/location-action", (req, res) => {
  syncReportExportCacheFromDisk();
  const file = req.params.file; // e.g. "40061.json"
  const data = reportExportCache.get(file);

  if (!data) {
    return res.status(404).json({ error: "Report export not found" });
  }

  const { area_num, loc_num, action, text } = req.body;

  const locNumStr = String(loc_num ?? "").trim();
  const actionStr = String(action ?? "")
    .trim()
    .toLowerCase();

  if (!locNumStr || !actionStr) {
    return res.status(400).json({ error: "Missing loc_num or action" });
  }

  if (!["recount", "question"].includes(actionStr)) {
    return res.status(400).json({ error: "Invalid action type" });
  }

  const actionObj = {
    area_num,
    loc_num: locNumStr,
    action: actionStr,
    text: String(text ?? ""),
    // Use server timestamp so ordering/freshness is stable regardless of
    // client device clock drift.
    timestamp: new Date().toISOString(),
  };

  // 1) Persist into the dedicated store (survives restarts / export regeneration)
  syncLocationActionsStoreFromDiskIfChanged();
  if (!Array.isArray(locationActionsStore[file]))
    locationActionsStore[file] = [];
  locationActionsStore[file].push(actionObj);

  // optional cap so the store file can't grow forever
  if (locationActionsStore[file].length > 5000) {
    locationActionsStore[file] = locationActionsStore[file].slice(-5000);
  }

  try {
    saveLocationActionsToDisk();
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }

  // 2) Also update the cached export object so area JSON reflects the action.
  if (!Array.isArray(data.location_actions)) data.location_actions = [];
  data.location_actions.push(actionObj);

  // 2b) Mirror onto the specific location entry.
  const locs = Array.isArray(data.locations) ? data.locations : [];
  const normLoc = (v) =>
    String(v ?? "")
      .trim()
      .replace(/,/g, "")
      .replace(/\.0+$/, "")
      .replace(/^0+(\d)/, "$1");
  const wanted = normLoc(locNumStr);
  const targetLoc = locs.find((l) => {
    if (!l || typeof l !== "object") return false;
    const locKey = normLoc(l.loc_num ?? l.LOC_NUM ?? l.locNum ?? "");
    return locKey === wanted;
  });

  if (targetLoc && typeof targetLoc === "object") {
    targetLoc.action = actionStr;
    if (!Array.isArray(targetLoc.actions)) targetLoc.actions = [];
    targetLoc.actions.push(actionObj);
  }

  // 3) Write back the export file atomically.
  const filePath = path.join(REPORT_DIR, file);
  try {
    const tmpPath = filePath + ".tmp";
    fs.writeFileSync(tmpPath, JSON.stringify(data, null, 2), "utf8");
    fs.renameSync(tmpPath, filePath);
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }

  reportExportCache.set(file, data);
  invalidateReportExportsBundleCache();

  return res.json({ success: true, action: actionObj });
});

// â”€â”€â”€ POST /api/reports/:name â”€â”€â”€
// Autosave without marking complete (leaves enabled/completedAt untouched)
app.post("/api/reports/:name", (req, res) => {
  const fileName = req.params.name;
  const filePath = path.join(JSON_DIR, fileName);
  if (!fs.existsSync(filePath)) {
    return res.status(404).json({ error: "Report not found" });
  }
  try {
    // 1) Load the existing JSON
    const obj = readJsonFile(filePath);

    // 2) Replace only the records array
    if (Array.isArray(req.body.records)) {
      obj.records = req.body.records;
    } else {
      return res.status(400).json({ error: "Missing records array" });
    }

    // 3) Atomically write back to disk
    const tmpPath = filePath + ".tmp";
    fs.writeFileSync(tmpPath, JSON.stringify(obj, null, 2), "utf8");
    fs.renameSync(tmpPath, filePath);

    // Keep in-memory cache/index hot without waiting for fs.watch timing.
    reportCache.set(fileName, obj);
    scheduleEnabledDataIndexRebuild();

    return res.json({ success: true });
  } catch (err) {
    console.error("Autosave error:", err);
    return res.status(500).json({ error: err.message });
  }
});

// â”€â”€â”€ POST reviewed flag â”€â”€â”€
// Body: { reviewed: true/false, reviewed_at?: ISO string }
app.post("/api/report-exports/:file/seen", (req, res) => {
  syncReportExportCacheFromDisk();
  const file = req.params.file;
  if (!reportExportCache.has(file)) {
    return res.status(404).json({ error: "Report export not found" });
  }

  const seen_at =
    typeof req.body?.seen_at === "string" && req.body.seen_at.trim()
      ? req.body.seen_at
      : new Date().toISOString();

  syncReviewStatusStoreFromDiskIfChanged();
  applySeenStateForFile(file, seen_at);
  const effective = reviewStatusStore[file];

  try {
    saveReviewStatusToDisk();
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }

  return res.json({
    success: true,
    file,
    seen_at:
      effective && typeof effective.seen_at === "string"
        ? effective.seen_at
        : seen_at,
  });
});

app.post("/api/report-exports/reviewed-batch", (req, res) => {
  syncReportExportCacheFromDisk();
  const files = Array.isArray(req.body?.files) ? req.body.files : [];
  const reviewed = req.body?.reviewed === true;
  const reviewed_at =
    typeof req.body?.reviewed_at === "string"
      ? req.body.reviewed_at
      : new Date().toISOString();

  const normalizedFiles = files
    .map((f) => String(f || "").trim())
    .filter(Boolean);

  if (normalizedFiles.length === 0) {
    return res.status(400).json({ error: "Missing files array" });
  }

  syncReviewStatusStoreFromDiskIfChanged();

  const updated = [];
  const missing = [];
  for (const file of normalizedFiles) {
    if (applyReviewedStateForFile(file, reviewed, reviewed_at)) updated.push(file);
    else missing.push(file);
  }

  try {
    saveReviewStatusToDisk();
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }

  return res.json({
    success: true,
    reviewed,
    reviewed_at,
    updated,
    missing,
  });
});

app.post("/api/report-exports/:file/reviewed", (req, res) => {
  syncReportExportCacheFromDisk();
  const file = req.params.file; // e.g. "20100.json"
  if (!reportExportCache.has(file)) {
    return res.status(404).json({ error: "Report export not found" });
  }

  const reviewed = req.body?.reviewed === true;
  const reviewed_at =
    typeof req.body?.reviewed_at === "string"
      ? req.body.reviewed_at
      : new Date().toISOString();

  syncReviewStatusStoreFromDiskIfChanged();
  applyReviewedStateForFile(file, reviewed, reviewed_at);
  const effective = reviewStatusStore[file];
  try {
    saveReviewStatusToDisk();
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }

  return res.json({
    success: true,
    file,
    reviewed,
    reviewed_at:
      effective && typeof effective.reviewed_at === "string"
        ? effective.reviewed_at
        : "",
  });
});

// â”€â”€â”€ POST /api/reports/:name/complete â”€â”€â”€
app.post("/api/reports/:name/complete", (req, res) => {
  const fileName = req.params.name;
  const srcPath = path.join(JSON_DIR, fileName);
  const COMPLETE_DIR = path.join(JSON_DIR, "Complete");
  const dstPath = path.join(COMPLETE_DIR, fileName);

  // 1) Ensure the source file exists
  if (!fs.existsSync(srcPath)) {
    return res.status(404).json({ error: "File not found" });
  }

  // 2) Create the â€œCompleteâ€ directory if needed
  fs.mkdirSync(COMPLETE_DIR, { recursive: true });

  try {
    // 3) Load and update the JSON
    const obj = readJsonFile(srcPath);
    const incomingRecords = Array.isArray(req.body?.records)
      ? req.body.records
      : Array.isArray(obj.records)
        ? obj.records
        : [];

    const invalidManualSkuRows = incomingRecords.filter((rec) => {
      if (!rec || rec.deleted === true) return false;

      const foundStatus = String(rec.FOUND_STAT ?? "")
        .trim()
        .toUpperCase();
      if (foundStatus !== "F") return false;

      const hasCategory =
        rec.CAT_NUM !== null &&
        rec.CAT_NUM !== undefined &&
        String(rec.CAT_NUM).trim() !== "";
      const hasPrice =
        rec.PRICE !== null &&
        rec.PRICE !== undefined &&
        String(rec.PRICE).trim() !== "" &&
        Number.isFinite(Number(rec.PRICE));

      return !(hasCategory && hasPrice);
    });

    if (invalidManualSkuRows.length > 0) {
      return res.status(400).json({
        error:
          "Category and price are required for SKU errors before marking location complete.",
      });
    }

    if (Array.isArray(req.body.records)) {
      obj.records = incomingRecords;
    }
    obj.enabled = false;
    obj.completedAt = new Date().toISOString();

    // 4) Atomically write to the new file, delete the old
    const tempPath = dstPath + ".tmp";
    fs.writeFileSync(tempPath, JSON.stringify(obj, null, 2), "utf8");
    fs.renameSync(tempPath, dstPath);
    fs.unlinkSync(srcPath);

    // remove from the in-memory cache so itâ€™s no longer treated as â€œenabledâ€
    reportCache.delete(fileName);
    rebuildEnabledDataIndex();

    // 5) Update employeeâ€‘completion flags
    const empData = loadEmployees();
    incomingRecords.forEach((rec) => {
      const nm = rec.employee_name;
      if (nm && !empData.hasOwnProperty(nm)) {
        empData[nm] = false;
      }
    });

    // 6) Reâ€scan enabled reports and finalize each employeeâ€™s status
    loadEnabledReports((err2, reps2) => {
      if (err2) {
        console.error("loadEnabledReports failed:", err2);
        return res.status(500).json({ error: err2.message });
      }

      incomingRecords.forEach((rec) => {
        const nm = rec.employee_name;
        const stillHas = reps2.some((r) =>
          r.data.records?.some((r2) => r2.employee_name === nm),
        );
        if (!stillHas) {
          empData[nm] = true;
        }
      });

      saveEmployees(empData);

      // 7) Send exactly one success response
      return res.json({ success: true });
    });
  } catch (err) {
    console.error("Error completing report:", err);
    return res.status(500).json({ error: err.message });
  }
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});

