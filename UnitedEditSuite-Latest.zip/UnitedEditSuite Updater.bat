@echo off
setlocal EnableExtensions EnableDelayedExpansion

:: ===========================================
:: Paths, constants, and log
:: ===========================================
set "SCRIPT_DIR=%~dp0"
set "LOG=%SCRIPT_DIR%install.log"
set "DL=%SCRIPT_DIR%downloads"
set "SETUP_EXE=%DL%\UnitedSetup.msi"
set "SRC_AUD=%SCRIPT_DIR%auditorsite"
set "DEST_ROOT=C:\USUnitedEdit\Reports"
set "DEST_DIR=%DEST_ROOT%\AuditorSite"

:: UnitedSetup MSI Product Code (from your WMIC output)
set "UNITED_GUID={4B667501-430C-4885-81EE-851FBC4BE484}"

>>"%LOG%" echo ==== Run started %DATE% %TIME% ====
call :log "Script dir      : %SCRIPT_DIR%"
call :log "Downloads dir   : %DL%"
call :log "AuditorSite src : %SRC_AUD%"
call :log "Dest dir        : %DEST_DIR%"
call :log "United GUID     : %UNITED_GUID%"

:: ===========================================
:: 1) Uninstall existing UnitedSetup (MSI)
:: ===========================================
call :log "Checking/uninstalling existing UnitedSetup (if present)..."
call :msi_uninstall "%UNITED_GUID%"

:: ===========================================
:: 2) Run UnitedSetup.msi with visible progress if present
:: ===========================================
if not exist "%SETUP_EXE%" (
  call :log "ERROR: '%SETUP_EXE%' not found. Skipping setup."
) else (
  call :log "Running UnitedSetup.msi with passive progress UI..."
  msiexec /i "%SETUP_EXE%" /passive /norestart /L*v "%TEMP%\UnitedSetup_install.log" >>"%LOG%" 2>&1
  set "RC=%ERRORLEVEL%"
  if %RC% NEQ 0 (
    call :log "ERROR: UnitedSetup.msi returned %RC%. Check %TEMP%\UnitedSetup_install.log"
  ) else (
    call :log "UnitedSetup.msi completed."
  )
)

:: ===========================================
:: 3) Copy AuditorSite to destination
:: ===========================================
if not exist "%SRC_AUD%" (
  call :log "ERROR: Source folder '%SRC_AUD%' not found. Skipping copy."
) else (
  if not exist "%DEST_ROOT%" mkdir "%DEST_ROOT%" >>"%LOG%" 2>&1
  call :log "Copying '%SRC_AUD%' -> '%DEST_DIR%' ..."
  robocopy "%SRC_AUD%" "%DEST_DIR%" /E /XO /R:2 /W:2 >>"%LOG%" 2>&1
  set "RC=%ERRORLEVEL%"
  if %RC% GEQ 8 (
    call :log "ERROR: Robocopy failed with code %RC%."
  ) else (
    call :log "Copy completed (robocopy code %RC%)."
  )
)

call :log "All done."
echo.
echo Finished. See log: "%LOG%"
exit /b 0

:: ===========================================
:: Functions
:: ===========================================
:log
echo %~1
>>"%LOG%" echo %~1
exit /b

:msi_uninstall
:: %1 = {PRODUCT-GUID}
set "GUID=%~1"
if "%GUID%"=="" (
  call :log "ERROR: No GUID provided to :msi_uninstall."
  exit /b 1
)

:: Try uninstall; treat "not installed" as success for updater.
call :log "Attempting msiexec uninstall: %GUID%"
msiexec /x %GUID% /qn /norestart /L*v "%TEMP%\UnitedSetup_uninstall.log" >>"%LOG%" 2>&1
set "RC=%ERRORLEVEL%"

if "%RC%"=="0" (
  call :log "Uninstall succeeded (0)."
  exit /b 0
) else if "%RC%"=="1605" (
  call :log "Product not installed (1605). Continuing."
  exit /b 0
) else if "%RC%"=="1614" (
  call :log "Product already uninstalled (1614). Continuing."
  exit /b 0
) else if "%RC%"=="3010" (
  call :log "Uninstall succeeded but reboot required (3010). Proceeding."
  exit /b 0
) else (
  call :log "WARNING: msiexec returned %RC%. Check %TEMP%\UnitedSetup_uninstall.log"
  exit /b %RC%
)
